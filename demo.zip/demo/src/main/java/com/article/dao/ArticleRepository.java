package com.article.dao;

import java.util.Date;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.article.entities.ArticleEntity;

public interface ArticleRepository extends CrudRepository<ArticleEntity, Integer>{

	@Modifying
	@Query("update ArticleEntity u set u.title = ?1, u.description = ?2, u.body = ?3, u.updatedAt = ?4 where u.id = ?5")
	void setArticleBySlugId(String title, String description, String body, Date updatedAt, int slugId);

	@Query("select ArticleEntity u  where u.slug = ?1")
	ArticleEntity fetchArticleBySlugId(String slugId);
	
	@Query("delete ArticleEntity u  where u.slug = ?1")
	void deleteBySlugId(String slugId);
}
