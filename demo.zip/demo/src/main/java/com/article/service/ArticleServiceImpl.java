package com.article.service;

import java.util.Date;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.article.dao.ArticleRepository;
import com.article.data.Article;
import com.article.data.ArticleResponseTime;
import com.article.data.TimeToRead;
import com.article.entities.ArticleEntity;

@org.springframework.transaction.annotation.Transactional
@Service
public class ArticleServiceImpl implements ArticleService{

	@Autowired
	ArticleRepository repository;

	@Value("${average.human.speed}")
	private int humanSpeed;

	@Override
	public ArticleEntity createArticle(Article article) {

		ArticleEntity entity = new ArticleEntity();
		entity.setBody(article.getBody());
		entity.setCreatedAt(new Date());
		entity.setDescription(article.getDescription());
		entity.setSlug( article.getTitle().toLowerCase().replace(" ", "-"));
		entity.setTitle(article.getTitle());
		entity.setUpdatedAt(new Date());
		repository.save(entity);
		return entity;
	}

	@Override
	public ArticleEntity fetchArticle(int slugId) {
		Optional<ArticleEntity> entity =  repository.findById(slugId);
		if(entity.isPresent()) {
			return entity.get();
		}
		else {
			return null;
		}
	}

	@Override
	public ArticleEntity updateArticle(Article article) {
		repository.setArticleBySlugId(article.getTitle(), article.getDescription(), article.getBody(), 
				new Date(), article.getId());
		Optional<ArticleEntity> entity =  repository.findById(article.getId());
		if(entity.isPresent()) {
			return entity.get();
		}
		return null;
	}

	@Override
	public void deleteArticle(int slugId) {
		repository.deleteById(slugId);
	}

	@Override
	public ArticleResponseTime findTime(int id) {
		Optional<ArticleEntity> entity =  repository.findById(id);
		ArticleResponseTime time = new ArticleResponseTime();
		if(entity.isPresent()) {
			ArticleEntity entityData = entity.get();
			time.setArticleId(entityData.getSlug());
			TimeToRead timetoRead = new TimeToRead();
			double timetaken = entityData.getTitle().length() / humanSpeed;
			timetoRead.setMins((int) timetaken);
			timetoRead.setSeconds((int)(timetaken - (int) timetaken));
			time.setTimeToRead(timetoRead);
			return time;
		}
		return time;


	}

}
