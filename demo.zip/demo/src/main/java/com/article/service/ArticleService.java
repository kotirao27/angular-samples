package com.article.service;

import com.article.data.Article;
import com.article.data.ArticleResponseTime;
import com.article.entities.ArticleEntity;

public interface ArticleService {

	public ArticleEntity createArticle(Article article);

	public ArticleEntity fetchArticle(int slugId);

	public ArticleEntity updateArticle(Article article);
	
	public void deleteArticle(int slugId);

	public ArticleResponseTime findTime(int id);

}
