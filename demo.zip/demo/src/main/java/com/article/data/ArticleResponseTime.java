package com.article.data;

public class ArticleResponseTime {

	private String articleId;
	private TimeToRead timeToRead;
	
	public String getArticleId() {
		return articleId;
	}
	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}
	public TimeToRead getTimeToRead() {
		return timeToRead;
	}
	public void setTimeToRead(TimeToRead timeToRead) {
		this.timeToRead = timeToRead;
	}
}
