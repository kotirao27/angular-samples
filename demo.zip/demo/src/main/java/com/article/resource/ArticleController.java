package com.article.resource;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.article.data.Article;
import com.article.data.ArticleResponseTime;
import com.article.entities.ArticleEntity;
import com.article.service.ArticleService;

@RequestMapping(value = "article")
@RestController
public class ArticleController {

	@Autowired
	ArticleService service;

	@PostMapping(value = "create")
	public ArticleEntity createArticle(@RequestBody @Valid Article article) {

		return service.createArticle(article);

	}

	@GetMapping(value = "fetch/{id}")
	public ResponseEntity<ArticleEntity> fetchArticle(@PathVariable(required = true) int id) {
		ArticleEntity response = service.fetchArticle(id);
		if(response  != null) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping(value = "update")
	public ArticleEntity updateArticle(@RequestBody @Valid Article article) {

		return service.updateArticle(article);

	}

	@GetMapping(value = "delete/{id}")
	public void deleteArticle(@PathVariable(required = true) int id) {
		service.deleteArticle(id);
	}

	@GetMapping(value = "delete/{id}")
	public ArticleResponseTime findTime(@PathVariable(required = true) int id) {
		return service.findTime(id);
	}

}
