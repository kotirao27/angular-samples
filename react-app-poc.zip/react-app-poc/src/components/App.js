import React, { Component } from "react";
import '../styles/App.css';
import Schools from "../components/Schools.js";
import { render } from 'react-dom';


class App extends Component {

    render() {    
        return (
            <div>
            <div className="row" ></div>
            <div className="row">
                        <div className="col-lg-6">
                         <h1 className="hide"><a>NWEA</a></h1>
                         <a ><img id="logo" className="img-responsive" src="nwea_img.png" alt="NWEA"></img></a>
                       </div> 
                     
                       <div className="col-lg-6">
                               <form name="loginForm">
                           <div className="row">
                               <div className="col-lg-3">
                                   <input type="text" className="form-control" placeholder="username"></input>
                             </div>
                               <div className="col-lg-3">
                               <input type="password" className="form-control" placeholder="password"></input>
                             </div>
                             <div className="col-lg-2">
                                   <input type="submit" className="btn btn-md btn-warning" value="Login" onClick={this.login} />
                             </div>
                             
                       </div>
                   </form>
                       </div>
           
           </div>           
               <div className="row">
                   <div className="col-xs-12"> 
                     <img src="img2.jpg" className="img-responsive" alt="Responsive image"></img>                   
               </div>
               </div>
                
               
                   <div className="row" id="newsfeed">
                     <header className="col-lg-12 col-lg-offset-1"><h3>Latest Posts</h3></header>
                     <section id="content" className="col-lg-10 col-lg-offset-1"><article className="blog" id="id-8269">
                       <b aria-expanded="true" className="clicker" data-toggle="collapse" data-target="#inner-8269">
                        | Seven Crucial Criteria for a Great Growth Assessment – Post One</b>
                        <div id="inner-8269" className="collapse in"><small><b>Derrick Vargason | <a href="/blog/category/assessment-basics">Assessment Basics</a>, 
                        <a href="/blog/category/map-growth">MAP Growth</a> | 6.26.2018</b>
                        </small>“I need to know if my students are learning.” Sound familiar? We hear it a lot, and if you’re an educator, you’ve likely not only heard it,...  
                         <a href="https://www.nwea.org/blog/2018/seven-crucial-criteria-great-growth-assessment/"><b>MORE</b></a></div></article><article className="news" id="id-13982">
                         <b className="clicker" data-toggle="collapse" data-target="#inner-13982">NEWS | NWEA Appoints Abby Javurek as Senior Director of Large Scale Assessment Solutions</b>
                         <div id="inner-13982" className="collapse"><small><b>Tiffani LeClair | <a href="/category/news">NWEA News</a>, <a href="/category/press-releases">Press Releases</a> 
                         | 6.26.2018</b></small>   <a href="https://www.nwea.org/2018/06/nwea-appoints-abby-javurek-as-senior-director-of-large-scale-assessment-solutions/"><b>MORE</b>
                         </a>&nbsp;</div></article><article className="news" id="id-13971"><b className="clicker" data-toggle="collapse" data-target="#inner-13971">
                         NEWS | Ohio Department of Education Selects NWEA MAP Growth as a Pre-Approved Assessment for Ohio Schools for Eighth Consecutive Year</b>
                         <div id="inner-13971" className="collapse"><small><b>Tiffani LeClair | <a href="/category/press-releases">Press Releases</a> | 6.25.2018</b></small>
                            <a href="https://www.nwea.org/2018/06/ohio-department-of-education-selects-nwea-map-growth-as-a-pre-approved-assessment-for-ohio-schools-for-eighth-consecutive-year/">
                            <b>MORE</b></a>&nbsp;</div></article><article className="blog" id="id-8260">
                            <b className="clicker" data-toggle="collapse" data-target="#inner-8260">BLOG | The 10 R’s of Summer? You Bet!</b><div id="inner-8260" className="collapse">
                            <small><b>Joi Converse | <a href="/blog/category/classroom-tips">Classroom Tips</a>, <a href="/blog/category/nwea">NWEA</a> | 6.21.2018</b>
                            </small>As we drift into summer, we often hear about the three Rs – reading, (w)riting, and (a)rithmetic. But as Dale Basye reflects over on our online community,...   
                            <a href="https://www.nwea.org/blog/2018/the-10-rs-of-summer-you-bet/"><b>MORE</b></a>&nbsp;</div></article></section>
                   </div> 
                   </div>                                            
        );
    }

    login() {
        render(<Schools />, document.getElementById('root'));
    };
}

export default App;