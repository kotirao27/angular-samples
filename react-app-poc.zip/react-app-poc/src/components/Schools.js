import React, { Component } from "react";
import { BootstrapTable, TableHeaderColumn, DeleteButton, InsertButton } from 'react-bootstrap-table';

class Schools extends Component {

    schools = [];

    constructor() {
        super()
        this.getSchools();
    }

    render() {

        const options = {
            deleteBtn: this.createCustomDeleteButton,
            insertBtn: this.createCustomInsertButton
          };
          const selectRow = {
            mode: 'checkbox'
          };     

        return (
            
            <div className="container">
            <div><h1>Schools</h1></div>
            <div className='row col-lg-12'>
            <BootstrapTable selectRow={ selectRow }  striped={true} hover={true} data={ this.schools } options={ options } exportCSV insertRow deleteRow>
            <TableHeaderColumn dataField="id" isKey={true} dataAlign="center" dataSort={true}>School ID</TableHeaderColumn>
            <TableHeaderColumn dataField="name" dataSort={true}>School Name</TableHeaderColumn>
            <TableHeaderColumn dataField="location" >Location</TableHeaderColumn>
            </BootstrapTable>
            </div>
            </div>
        );
    }

    handleDeleteButtonClick = (onClick) => {  
        //      
        onClick();
    }
    
    createCustomDeleteButton = (onClick) => {
        return (
          <DeleteButton
            btnText='Delete'
            btnContextual='btn-danger'
            className='my-custom-class'            
            onClick={ e => this.handleDeleteButtonClick(onClick) }/>
        );        
    }

    handleInsertButtonClick = (onClick) => {
        //
        onClick();
      }
    
      createCustomInsertButton = (onClick) => {
        return (
          <InsertButton
            btnText='New'
            btnContextual='btn-warning'
            className='my-custom-class'            
            onClick={ () => this.handleInsertButtonClick(onClick) }/>
        );
      }


    getSchools() {
        this.schools = [{
            id: 'schoo1',
            name : 'First School',            
            location: 'IN'
        },{
            id: 'schoo2',
            name : 'Second School',            
            location: 'MY'      
        }                        
        ]

    }
}
export default Schools;