import React from "react";
import App from "./components/App.js";
import { render } from 'react-dom';

render(<App />, document.getElementById('root'));